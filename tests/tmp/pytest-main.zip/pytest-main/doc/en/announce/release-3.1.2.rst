pytest-3.1.2
=======================================

pytest 3.1.2 has just been released to PyPI.

This is a bug-fix release, being a drop-in replacement. To upgrade::

  pip install --upgrade pytest

The full changelog is available at http://doc.pytest.org/en/stable/changelog.html.

Thanks to all who contributed to this release, among them:

* Andreas Pelme
* ApaDoctor
* Bruno Oliveira
* Florian Bruhin
* Ronny Pfannschmidt
* Segev Finer


Happy testing,
The pytest Development Team
