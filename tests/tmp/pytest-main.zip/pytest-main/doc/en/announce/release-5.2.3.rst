pytest-5.2.3
=======================================

pytest 5.2.3 has just been released to PyPI.

This is a bug-fix release, being a drop-in replacement. To upgrade::

  pip install --upgrade pytest

The full changelog is available at https://docs.pytest.org/en/stable/changelog.html.

Thanks to all who contributed to this release, among them:

* Anthony Sottile
* Brett Cannon
* Bruno Oliveira
* Daniel Hahler
* Daniil Galiev
* David Szotten
* Florian Bruhin
* Patrick Harmon
* Ran Benita
* Zac Hatfield-Dodds
* Zak Hassan


Happy testing,
The pytest Development Team
